//
//  AppDelegate.h
//  ContactList
//
//  Created by Marks, Jonathan A on 10/23/13.
//  Copyright (c) 2013 Marks, Jonathan A. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContactModel.h"

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@property (strong, nonatomic) UINavigationController *navigationController;

@end
