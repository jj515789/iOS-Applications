//
//  storageClass.m
//  scoreboard database
//
//  Created by Solensky, Ryan Joseph on 12/10/13.
//  Copyright (c) 2013 Solensky, Ryan Joseph. All rights reserved.
//

#import "storageClass.h"
#import "contactModel.h"


static storageClass *_myOnlyInstance = nil;

@implementation storageClass
{
    sqlite3* database;
}

@synthesize list = _list;

+(storageClass*)shared
{
    if (_myOnlyInstance == nil)
    {
        _myOnlyInstance = [[storageClass alloc]init];
        [_myOnlyInstance openDataBase];
        [_myOnlyInstance loadDataBase];
    }
    return _myOnlyInstance;
}

-(id)init
{
    self = [super init];
    if (self)
    {
        _list = [[NSMutableArray  alloc]init];
    }
    return self;
}

-(NSString*) path
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains (NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsPath = [paths objectAtIndex:0];
    NSString *plistPath = [documentsPath stringByAppendingPathComponent:@"database3.rdb"];
    NSLog(@"%@",plistPath);
    return plistPath;
}
-(void) testData
{
    contactModel *person = [[contactModel alloc]init];
    contactModel *person2 = [[contactModel alloc] init];
    
    person.username = @"Jon";
    person.score = 210;
    person2.username = @"Ryan";
    person2.score = 190;
    
    [self addContact:person];
    [self addContact:person2];
    
    
    [person release];
    [person2 release];
}
-(void)addContact: (contactModel*) cm
{
    
    NSString *rec = [NSString stringWithFormat:@"Insert into contacts (username, score) Values ('%@', '%i')",cm.username, cm.score];
    
    char *array;
    
    if (sqlite3_exec(database, [rec UTF8String], NULL, NULL, &array) != SQLITE_OK)
    {
        sqlite3_close(database);
        NSLog(@"Error updating");
    }
    [self loadDataBase];
}

-(void)loadDataBase
{
    if (_list != nil)
    {
        [_list release];
    }
    
    _list = [[NSMutableArray alloc] init];
    
    NSString *load = [NSString stringWithFormat:@"select * from contacts order by score desc;"];
    sqlite3_stmt *loadStatement;
    
    if (sqlite3_prepare_v2(database, [load UTF8String], -1, &loadStatement, nil) == SQLITE_OK)
    {
        while (sqlite3_step(loadStatement) == SQLITE_ROW)
        {
            contactModel* c = [[contactModel alloc] init];
            c.username = [NSString stringWithUTF8String:(char *)sqlite3_column_text(loadStatement, 0)];
            c.score = sqlite3_column_int(loadStatement, 1);
            c.index = sqlite3_column_int(loadStatement, 2);
            
            [self.list addObject:c];
            [c release];
        }
        sqlite3_finalize(loadStatement);
    }
}

-(void)createDataBase
{
    NSString* createString = @"CREATE TABLE IF NOT EXISTS contacts ("
    @"username Varchar(50),"
    @"score integer,"
    @"id integer PRIMARY KEY AUTOINCREMENT DEFAULT 0);";
    char *array;
    if (sqlite3_exec(database, [createString UTF8String], NULL, NULL, &array) != SQLITE_OK)
    {
        sqlite3_close(database);
    }
    
}

-(void)openDataBase
{
    if (sqlite3_open([[self path]UTF8String], &database)!= SQLITE_OK)
    {
        sqlite3_close(database);
    }
    else
    {
        [self createDataBase];
    }
}

@end
