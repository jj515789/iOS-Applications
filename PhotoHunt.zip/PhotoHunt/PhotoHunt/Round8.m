//
//  Round8.m
//  PhotoHunt
//
//  Created by Marks, Jonathan A on 12/4/13.
//  Copyright (c) 2013 Marks, Jonathan A; Solensky, Ryan J. All rights reserved.
//

#import "Round8.h"
#import "Round4.h"
#import "ViewController.h"
#import "AppDelegate.h"
#import "TableViewController.h"
#import "storageClass.h"
#import "contactModel.h"

@interface Round8 ()
{
    NSTimer *timer;
    int remainingCounts;
}

@property (nonatomic, retain) IBOutlet UIImageView* iv1;
@property (nonatomic, retain) IBOutlet UIImageView* iv2;
@property (nonatomic, retain) IBOutlet UIImageView* iv3;
@property (nonatomic, retain) IBOutlet UILabel* time;
@property (nonatomic, retain) IBOutlet UILabel* scoreLabel;
@property (nonatomic, retain) IBOutlet UILabel* complete;

@end

@implementation Round8

@synthesize iv1 = _iv1;
@synthesize iv2 = _iv2;
@synthesize iv3 = _iv3;
@synthesize time = _time;
@synthesize scoreLabel = _scoreLabel;
@synthesize complete = _complete;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}
-(void) mainMenu
{
    ViewController* vc;
    vc = [[[ViewController alloc] initWithNibName:@"ViewController" bundle:nil] autorelease];
    [self.navigationController pushViewController:vc animated:NO];
}
-(IBAction)mainScreenClicked:(id)sender
{
    [timer invalidate];
    AppDelegate *ad = (AppDelegate*) [[UIApplication sharedApplication] delegate];
    ad.score = 0;
    [self mainMenu];
}
- (IBAction)buttonClicked:(id)sender
{
    AppDelegate *ad = (AppDelegate*) [[UIApplication sharedApplication] delegate];
    
    UIButton *buttonThatWasPressed = (UIButton *)sender;
    buttonThatWasPressed.enabled = NO;
    
    if ([sender tag] == 0)
    {
        self.iv1.hidden = NO;
        ad.score = ad.score + 10;
        self.scoreLabel.text = [NSString stringWithFormat:@"%i",ad.score];
        [self plusTen];
        
    }
    if ([sender tag] == 1)
    {
        self.iv2.hidden = NO;
        ad.score = ad.score + 10;
        self.scoreLabel.text = [NSString stringWithFormat:@"%i",ad.score];
        [self plusTen];
    }
    if ([sender tag] == 2)
    {
        self.iv3.hidden = NO;
        ad.score = ad.score + 10;
        self.scoreLabel.text = [NSString stringWithFormat:@"%i",ad.score];
        [self plusTen];
    }
    
    if(self.iv1.hidden == NO && self.iv2.hidden == NO && self.iv3.hidden == NO)
    {
        self.complete.hidden = NO;
        [self performSelector:@selector(beatRound) withObject:self afterDelay:4.0];
        [timer invalidate];
    }
}
-(void)countDown
{
    NSString* timeNow = [NSString stringWithFormat:@"%i", remainingCounts];
    self.time.text = timeNow;
    
    if (--remainingCounts == -1)
    {
        [timer invalidate];
        [self gameOver];
    }
}
-(void) gameOver
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"GAME OVER" message:@"Enter Your Name" delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    [alert show];
    [alert release];
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    AppDelegate *ad = (AppDelegate*) [[UIApplication sharedApplication] delegate];
    
    contactModel *person = [[contactModel alloc]init];
    
    person.username = [alertView textFieldAtIndex:0].text;
    person.score = ad.score;
    
    [[storageClass shared] addContact:person];
    [person release];
    
    [self scoreBoard];
}
-(void) scoreBoard
{
    TableViewController* vc;
    vc = [[[TableViewController alloc] initWithNibName:@"TableViewController" bundle:nil] autorelease];
    [self.navigationController pushViewController:vc animated:YES];
}
-(void) beatRound
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Congratulations You Won!" message:@"Enter Your Name For The Leaderboard" delegate:self cancelButtonTitle:@"Done" otherButtonTitles:nil];
    alert.alertViewStyle = UIAlertViewStylePlainTextInput;
    [alert show];
    [alert release];
}
-(void)plusTen
{
    UIImageView *imageView5 = [[UIImageView alloc] initWithFrame:CGRectMake(934, 50, 60, 60)];
    [imageView5 setImage:[UIImage imageNamed:@"sin10.png"]];
    [self.view addSubview:imageView5];
    
    [UIView animateWithDuration:0.6
                          delay:0.5
                        options:(UIViewAnimationOptionTransitionCurlUp)
                     animations:^{
                         imageView5.alpha = 0.0;
                     }
                     completion:^(BOOL completed) {}];
    
	[imageView5 release];
}
- (void)viewDidLoad
{
    AppDelegate *ad = (AppDelegate*) [[UIApplication sharedApplication] delegate];
    
    self.iv1.hidden = YES;
    self.iv2.hidden = YES;
    self.iv3.hidden = YES;
    self.navigationController.navigationBar.hidden = YES;
    self.scoreLabel.text = [NSString stringWithFormat:@"%i",ad.score];
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    timer = [NSTimer scheduledTimerWithTimeInterval:1
                                             target:self
                                           selector:@selector(countDown)
                                           userInfo:nil
                                            repeats:YES];
    remainingCounts = 20;
    
    [self countDown];
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end