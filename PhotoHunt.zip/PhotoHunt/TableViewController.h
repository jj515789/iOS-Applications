//
//  TableViewController.h
//  PhotoHunt
//
//  Created by Marks, Jonathan A on 12/10/13.
//  Copyright (c) 2013 Marks, Jonathan A; Solensky, Ryan J. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewController : UIViewController
{
    
}

@property(nonatomic, retain)IBOutlet UITableView* tableView;
-(IBAction)mainScreenClicked:(id)sender;

@end
