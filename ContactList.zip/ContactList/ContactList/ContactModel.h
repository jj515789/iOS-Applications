//
//  ContactModel.h
//  ContactList
//
//  Created by Marks, Jonathan A on 10/23/13.
//  Copyright (c) 2013 Marks, Jonathan A. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ContactModel : NSObject
{
    
}

-(id)init;
@property(nonatomic, retain)NSString* firstName;
@property(nonatomic, retain)NSString* lastName;
@property(nonatomic, retain)NSString* email;
@property(nonatomic, retain)NSString* phone;

+(NSMutableDictionary*) toDictionary: (ContactModel*) c;
+(ContactModel*) toContact: (NSMutableDictionary*) d;
-(void)dealloc;

@end
