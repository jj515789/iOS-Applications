//
//  contactModel.m
//  scoreboard database
//
//  Created by Solensky, Ryan Joseph on 12/10/13.
//  Copyright (c) 2013 Solensky, Ryan Joseph. All rights reserved.
//

#import "contactModel.h"
#import "storageClass.h"

@implementation contactModel

@synthesize username = _username;
@synthesize score = _score;

-(id)init
{
    self = [super init];
    if(!self)
    {
        return nil;
    }
    _username = [[NSString alloc]init];
    _score = 0;
    
    
    return self;
}

-(void)dealloc
{
    [_username release];
        [super dealloc];
}

@end