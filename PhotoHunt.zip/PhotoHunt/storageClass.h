//
//  storageClass.h
//  scoreboard database
//
//  Created by Solensky, Ryan Joseph on 12/10/13.
//  Copyright (c) 2013 Solensky, Ryan Joseph. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "contactModel.h"
#import "sqlite3.h"

@interface storageClass : NSObject
{
    NSMutableArray *_list;
}


@property(nonatomic, copy) NSMutableArray *list;

+(storageClass*)shared;
-(id)init;
-(NSString*) path;
-(void)addContact: (contactModel*) cm;
-(void)openDataBase;
-(void)createDataBase;
-(void)loadDataBase;
-(void)testData;

@end
