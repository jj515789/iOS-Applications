//
//  AppDelegate.h
//  PhotoHunt
//
//  Created by Marks, Jonathan A on 12/4/13.
//  Copyright (c) 2013 Marks, Jonathan A; Solensky, Ryan J. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ViewController *viewController;

@property (strong, nonatomic) UINavigationController* navigationController;

@property (nonatomic, assign) int score;

@end
