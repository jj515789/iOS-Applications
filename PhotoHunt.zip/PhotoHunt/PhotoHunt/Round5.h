//
//  Round5.h
//  PhotoHunt
//
//  Created by Marks, Jonathan A on 12/4/13.
//  Copyright (c) 2013 Marks, Jonathan A; Solensky, Ryan J. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Round5 : UIViewController
{
    
}

-(IBAction)mainScreenClicked:(id)sender;
-(IBAction)buttonClicked:(id)sender;

@end
