//
//  Storage.m
//  ContactList
//
//  Created by Marks, Jonathan A on 10/23/13.
//  Copyright (c) 2013 Marks, Jonathan A. All rights reserved.
//

#import "Storage.h"
#import "ContactModel.h"

static Storage *_myOnlyInstance = nil;

@implementation Storage

@synthesize list = _list;
@synthesize sortedArray = _sortedArray;

+(Storage*) shared
{
        if (_myOnlyInstance == nil) {
            _myOnlyInstance = [[Storage alloc]init];
        }
        return _myOnlyInstance;
}
-(id)init
{
    self = [super init];
    if (self) {
        _list = [[NSMutableArray alloc]init];
    }
    return self;
}
-(NSString*) getFilePath
{
    NSArray *path = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docPath = [path objectAtIndex:0];
    NSString *filePath = [docPath stringByAppendingFormat:@"/file.plist"];
    return filePath;
}
-(void)addContact: (ContactModel*) c
{
    [self.list addObject: [ContactModel toDictionary:c]];
    [self.list writeToFile:[[Storage shared]getFilePath] atomically:YES];
}
-(ContactModel*)getContact: (NSUInteger) index
{
    return [ContactModel toContact:[self.list objectAtIndex:index]];
}
-(void)deleteContact:(NSInteger) index
{
    [self.list removeObjectAtIndex:index];
    [self.list writeToFile:[[Storage shared]getFilePath] atomically:YES];
}
-(NSMutableArray*) getAllContacts
{
    return self.list;
}
-(void)updateContact:(ContactModel *) c :(NSInteger) index
{
    [[self.list objectAtIndex:index] setObject:c.firstName forKey:@"fn"];
    [[self.list objectAtIndex:index] setObject:c.lastName forKey:@"ln"];
    [[self.list objectAtIndex:index] setObject:c.email forKey:@"email"];
    [[self.list objectAtIndex:index] setObject:c.phone forKey:@"phone"];
    
    [self.list writeToFile:[[Storage shared]getFilePath] atomically:YES];
}
-(void)updateContactList
{
    NSArray *arr = [NSArray arrayWithContentsOfFile:[[Storage shared]getFilePath]];
    for (NSInteger i = 0; i < [arr count]; ++i)
    {
        NSMutableDictionary *d = [arr objectAtIndex: i];
        [[Storage shared] addContact:[ContactModel toContact:d]];
    }
}
-(void)sort
{
    NSSortDescriptor* sorted = [[NSSortDescriptor alloc]initWithKey:@"ln" ascending:YES];
    _sortedArray = [_list sortedArrayUsingDescriptors:[NSArray arrayWithObject:sorted]];
    [[NSFileManager defaultManager]removeItemAtPath:[[Storage shared]getFilePath]error:nil];
    _list = [_sortedArray mutableCopy];
    [[Storage shared]updateContactList];
    [self.list writeToFile:[[Storage shared]getFilePath] atomically:YES];
    [sorted release];
    
}
@end
