//
//  SecondViewController.m
//  ContactList
//
//  Created by Marks, Jonathan A on 10/28/13.
//  Copyright (c) 2013 Marks, Jonathan A. All rights reserved.
//

#import "SecondViewController.h"
#import "AppDelegate.h"
#import "Storage.h"
#import "ContactModel.h"
#import "ViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

@synthesize fn = _fn;
@synthesize ln = _ln;
@synthesize em = _em;
@synthesize ph = _ph;
@synthesize Dict = _Dict;
@synthesize Index = _Index;
@synthesize reloadDelegate = _reloadDelegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(IBAction) doneEditing:(id)sender
{
    [sender resignFirstResponder];
}
-(IBAction)saveButtonClick:(id)sender
{
    
    if (_Index == -1)
    {
        ContactModel *c = [[ContactModel alloc]init];
        c.firstName = self.fn.text;
        c.lastName = self.ln.text;
        c.email = self.em.text;
        c.phone = self.ph.text;
        
        [[Storage shared] addContact: c];
        [c release];
        [[Storage shared] sort];
    }
    else
    {
        ContactModel *c = [[ContactModel alloc]init];
        c.firstName = self.fn.text;
        c.lastName = self.ln.text;
        c.email = self.em.text;
        c.phone = self.ph.text;
        
        [[Storage shared] updateContact: c :_Index];
        [c release];
        [[Storage shared] sort];
    }
    [self.reloadDelegate tableChange];
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)deleteButtonClick:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Alert!"
                                                   message:@"Are You Sure You Want To delete?"
                                                  delegate:self
                                         cancelButtonTitle:@"Cancel"
                                         otherButtonTitles:@"Yes", nil];
    [alert show];
    [alert release];
}
-(void) alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 1)
    {
        [[Storage shared]deleteContact:_Index];
        [self.reloadDelegate tableChange];
        [self.navigationController popViewControllerAnimated:YES];
    }
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.

    _fn.text = [_Dict objectForKey:@"fn"];
    _ln.text = [_Dict objectForKey:@"ln"];
    _em.text = [_Dict objectForKey:@"email"];
    _ph.text = [_Dict objectForKey:@"phone"];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
