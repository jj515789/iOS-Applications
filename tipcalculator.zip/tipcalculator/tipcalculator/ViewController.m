//
//  ViewController.m
//  tipcalculator
//
//  Created by Marks, Jonathan A on 9/25/13.
//  Copyright (c) 2013 Marks, Jonathan A. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize bill = _bill;
@synthesize thelabel = _thelabel;
@synthesize total = _total;

-(IBAction)btnClicked:(id)sender
{
    NSDecimalNumber *dinner = [[NSDecimalNumber alloc] initWithString: _bill.text];
    NSDecimalNumber *percent;
    NSDecimalNumber *tip;
    NSDecimalNumber *totbill;
    if([ViewController isNumeric:_bill.text])
    {
        if([sender tag] == 1)
        {
            percent = [NSDecimalNumber decimalNumberWithString:@"0.10"];
        }
        if([sender tag] == 2)
        {
            percent = [NSDecimalNumber decimalNumberWithString:@"0.15"];
        }
        if([sender tag] == 3)
        {
            percent = [NSDecimalNumber decimalNumberWithString:@"0.20"];
        }
        tip = [dinner decimalNumberByMultiplyingBy:percent];
        _thelabel.text = [NSString stringWithFormat:@"  $%@: tip", tip];
    
        totbill = [dinner decimalNumberByAdding:tip];
        _total.text = [NSString stringWithFormat:@"$%@", totbill];
    }
    else
    {
        UIAlertView *av = [[UIAlertView alloc] initWithTitle:@"Error in input"
                                                     message:@"Enter a number"
                                                    delegate:self
                                           cancelButtonTitle:@"OK"
                                           otherButtonTitles: nil];
        [av show];
        [av release];
    }
    
    [dinner release];

}

+(BOOL) isNumeric:(NSString*) s
{
    if([s length] == 0)
    {
        return false;
    }
    NSScanner *sc = [NSScanner scannerWithString: s];
    if([sc scanFloat:NULL])
    {
        return [sc isAtEnd];
    }
    return NO;
}
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void) dealloc
{
    [_bill release];
    [super dealloc];
}

@end
