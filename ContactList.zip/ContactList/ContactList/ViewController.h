//
//  ViewController.h
//  ContactList
//
//  Created by Marks, Jonathan A on 10/23/13.
//  Copyright (c) 2013 Marks, Jonathan A. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SecondViewController.h"

@interface ViewController : UIViewController <Reload>
{
    
}
@property(nonatomic, retain)IBOutlet UITableView* tableView;
@property (nonatomic, assign) NSInteger num;

@end
