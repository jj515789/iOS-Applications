//
//  main.m
//  PhotoHunt
//
//  Created by Marks, Jonathan A on 12/4/13.
//  Copyright (c) 2013 Marks, Jonathan A; Solensky, Ryan J. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
