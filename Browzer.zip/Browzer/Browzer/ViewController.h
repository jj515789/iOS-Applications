//
//  ViewController.h
//  Browzer
//
//  Created by Marks, Jonathan A on 10/4/13.
//  Copyright (c) 2013 Marks, Jonathan A. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
<UIAlertViewDelegate, UIActionSheetDelegate>
{
    IBOutlet UIPageControl *pageControl;
    IBOutlet UIWebView *webView1;
    IBOutlet UIWebView *webView2;
    IBOutlet UIWebView *webView3;
    IBOutlet UIWebView *webView4;
    IBOutlet UIWebView *webView5;
    int prevPage;
}

@property (nonatomic, retain) UIPageControl *pageControl;
@property (nonatomic, retain) UIWebView *webView1;
@property (nonatomic, retain) UIWebView *webView2;
@property (nonatomic, retain) UIWebView *webView3;
@property (nonatomic, retain) UIWebView *webView4;
@property (nonatomic, retain) UIWebView *webView5;
-(IBAction) btnNewsClicked:(id) sender;
-(IBAction) btnSportsClicked:(id) sender;
-(IBAction) btnShoppingClicked:(id) sender;
-(IBAction) btnSocialClicked:(id) sender;
-(IBAction) btnSchoolsClicked:(id) sender;

@end
