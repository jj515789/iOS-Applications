//
//  Storage.h
//  ContactList
//
//  Created by Marks, Jonathan A on 10/23/13.
//  Copyright (c) 2013 Marks, Jonathan A. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ContactModel.h"

@interface Storage : NSObject
{
    
}
+(Storage*) shared;
-(id) init;
-(void) addContact:(ContactModel*) c;
-(ContactModel*) getContact:(NSUInteger) index;
-(void)deleteContact:(NSInteger) index;
-(NSMutableArray*) getAllContacts;
-(void)updateContact: (ContactModel*)c :(NSInteger) index;
-(void)updateContactList;
-(void)sort;
-(NSString*) getFilePath;
@property (nonatomic, retain) NSMutableArray* list;
@property (nonatomic, retain) NSArray* sortedArray;

@end
