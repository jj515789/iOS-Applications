//
//  SecondViewController.h
//  ContactList
//
//  Created by Marks, Jonathan A on 10/28/13.
//  Copyright (c) 2013 Marks, Jonathan A. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol Reload

-(void) tableChange;

@end

@interface SecondViewController : UIViewController

@property (nonatomic, retain) IBOutlet UITextField *fn;
@property (nonatomic, retain) IBOutlet UITextField *ln;
@property (nonatomic, retain) IBOutlet UITextField *em;
@property (nonatomic, retain) IBOutlet UITextField *ph;
@property (nonatomic, retain) NSMutableDictionary *Dict;
@property (nonatomic, assign) NSInteger Index;
@property (nonatomic, assign) id<Reload> reloadDelegate;
-(IBAction) doneEditing:(id)sender;
-(IBAction)saveButtonClick:(id)sender;
-(IBAction)deleteButtonClick:(id)sender;

@end
