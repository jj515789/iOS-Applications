//
//  ViewController.m
//  Browzer
//
//  Created by Marks, Jonathan A on 10/4/13.
//  Copyright (c) 2013 Marks, Jonathan A. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize webView1 = _webView1;
@synthesize webView2 = _webView2;
@synthesize webView3 = _webView3;
@synthesize webView4 = _webView4;
@synthesize webView5 = _webView5;
@synthesize pageControl = pageControl;

-(void) actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSLog(@"%d", buttonIndex);
    switch (actionSheet.tag)
    {
        case 0:
            switch (buttonIndex)
        {
            case 0: buttonIndex = 0;
                NSURL *url01 = [NSURL URLWithString:@"http://www.cnn.com"];
                NSURLRequest *req01 = [NSURLRequest requestWithURL:url01];
                [_webView1 loadRequest:req01];
                break;
            case 1: buttonIndex = 1;
                NSURL *url11 = [NSURL URLWithString:@"http://www.foxnews.com"];
                NSURLRequest *req11 = [NSURLRequest requestWithURL:url11];
                [_webView1 loadRequest:req11];
                break;
            case 2: buttonIndex = 2;
                NSURL *url21 = [NSURL URLWithString:@"http://www.cspan.com"];
                NSURLRequest *req21 = [NSURLRequest requestWithURL:url21];
                [_webView1 loadRequest:req21];
        break;
        }
            break;
        case 1:
            switch (buttonIndex)
        {
            case 0: buttonIndex = 0;
                NSURL *url02 = [NSURL URLWithString:@"http://www.espn.com"];
                NSURLRequest *req02 = [NSURLRequest requestWithURL:url02];
                [_webView2 loadRequest:req02];
                break;
            case 1: buttonIndex = 1;
                NSURL *url12 = [NSURL URLWithString:@"http://www.nfl.com"];
                NSURLRequest *req12 = [NSURLRequest requestWithURL:url12];
                [_webView2 loadRequest:req12];
                break;
            case 2: buttonIndex = 2;
                NSURL *url22 = [NSURL URLWithString:@"http://www.armwrestling.com"];
                NSURLRequest *req22 = [NSURLRequest requestWithURL:url22];
                [_webView2 loadRequest:req22];
                break;
        }
        break;
        case 2:
            switch (buttonIndex)
        {
            case 0: buttonIndex = 0;
                NSURL *url03 = [NSURL URLWithString:@"http://www.buy.com"];
                NSURLRequest *req03 = [NSURLRequest requestWithURL:url03];
                [_webView3 loadRequest:req03];
                break;
            case 1: buttonIndex = 1;
                NSURL *url13 = [NSURL URLWithString:@"http://www.ebay.com"];
                NSURLRequest *req13 = [NSURLRequest requestWithURL:url13];
                [_webView3 loadRequest:req13];
                break;
        }
        break;
        case 3:
            switch (buttonIndex)
        {
            case 0: buttonIndex = 0;
                NSURL *url04 = [NSURL URLWithString:@"http://www.facebook.com"];
                NSURLRequest *req04 = [NSURLRequest requestWithURL:url04];
                [_webView4 loadRequest:req04];
                break;
            case 1: buttonIndex = 1;
                NSURL *url14 = [NSURL URLWithString:@"http://www.twitter.com"];
                NSURLRequest *req14 = [NSURLRequest requestWithURL:url14];
                [_webView4 loadRequest:req14];
        break;
        }
            break;
        case 4:
            switch (buttonIndex)
        {
            case 0: buttonIndex = 0;
                NSURL *url05 = [NSURL URLWithString:@"http://www.pitt.edu"];
                NSURLRequest *req05 = [NSURLRequest requestWithURL:url05];
                [_webView5 loadRequest:req05];
                break;
            case 1: buttonIndex = 1;
                NSURL *url15 = [NSURL URLWithString:@"http://www.upj.pitt.edu"];
                NSURLRequest *req15 = [NSURLRequest requestWithURL:url15];
                [_webView5 loadRequest:req15];
                break;
            case 2: buttonIndex = 2;
                NSURL *url25 = [NSURL URLWithString:@"http://www.upg.pitt.edu"];
                NSURLRequest *req25 = [NSURLRequest requestWithURL:url25];
                [_webView5 loadRequest:req25];
                break;
            case 3: buttonIndex = 3;
                NSURL *url35 = [NSURL URLWithString:@"http://www.psu.edu"];
                NSURLRequest *req35 = [NSURLRequest requestWithURL:url35];
                [_webView5 loadRequest:req35];
                break;
            case 4: buttonIndex = 4;
                NSURL *url45 = [NSURL URLWithString:@"http://www.iup.edu"];
                NSURLRequest *req45 = [NSURLRequest requestWithURL:url45];
                [_webView5 loadRequest:req45];
                break;
            case 5: buttonIndex = 5;
                NSURL *url55 = [NSURL URLWithString:@"http://www.pennhighlands.com"];
                NSURLRequest *req55 = [NSURLRequest requestWithURL:url55];
                [_webView5 loadRequest:req55];
                break;
        }
        break;
    }
}

-(IBAction) btnNewsClicked:(id) sender
{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Choose News"
                                                        delegate:self
                                               cancelButtonTitle:@"OK"
                                          destructiveButtonTitle:nil
                                               otherButtonTitles:@"CNN", @"Fox News",@"CSpan", nil];
    [action setTag: 0];
    [action showInView:self.view];
    [action release];
}
-(IBAction) btnSportsClicked:(id) sender
{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Choose Sports"
                                                        delegate:self
                                               cancelButtonTitle:@"OK"
                                          destructiveButtonTitle:nil
                                               otherButtonTitles:@"ESPN", @"NFL",@"Arm Wrestling", nil];
    [action setTag: 1];
    [action showInView:self.view];
    [action release];
}

-(IBAction) btnShoppingClicked:(id) sender
{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Choose Shopping"
                                                        delegate:self
                                               cancelButtonTitle:@"OK"
                                          destructiveButtonTitle:nil
                                               otherButtonTitles:@"Buy.com", @"Ebay", nil];
    [action setTag: 2];
    [action showInView:self.view];
    [action release];
}

-(IBAction) btnSocialClicked:(id) sender
{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Choose Social"
                                                        delegate:self
                                               cancelButtonTitle:@"OK"
                                          destructiveButtonTitle:nil
                                               otherButtonTitles:@"Facebook", @"Twitter", nil];
    [action setTag: 3];
    [action showInView:self.view];
    [action release];
}

-(IBAction) btnSchoolsClicked:(id) sender
{
    UIActionSheet *action = [[UIActionSheet alloc] initWithTitle:@"Choose Schools"
                                                        delegate:self
                                               cancelButtonTitle:@"OK"
                                          destructiveButtonTitle:nil
                                               otherButtonTitles:@"Pitt(main)", @"UPJ",@"UPG", @"Penn State",@"IUP",@"Penn Highlands", nil];
    [action setTag: 4];
    [action showInView:self.view];
    [action release];
}
- (void)viewDidLoad
{
    NSURL *url1 = [NSURL URLWithString:@"http://www.cnn.com"];
    NSURLRequest *req1 = [NSURLRequest requestWithURL:url1];
    [_webView1 loadRequest:req1];
    
    NSURL *url2 = [NSURL URLWithString:@"http://www.espn.com"];
    NSURLRequest *req2 = [NSURLRequest requestWithURL:url2];
    [_webView2 loadRequest:req2];
    
    NSURL *url3 = [NSURL URLWithString:@"http://www.buy.com"];
    NSURLRequest *req3 = [NSURLRequest requestWithURL:url3];
    [_webView3 loadRequest:req3];
    
    NSURL *url4 = [NSURL URLWithString:@"http://www.facebook.com"];
    NSURLRequest *req4 = [NSURLRequest requestWithURL:url4];
    [_webView4 loadRequest:req4];
    
    NSURL *url5 = [NSURL URLWithString:@"http://www.Pitt.edu"];
    NSURLRequest *req5 = [NSURLRequest requestWithURL:url5];
    [_webView5 loadRequest:req5];
    

    
    [pageControl addTarget:self
                     action:@selector(pageTurning:)
           forControlEvents:UIControlEventValueChanged];
    
    prevPage = 0;
    
    [super viewDidLoad];
}

-(void) pageTurning: (UIPageControl *) pageController
{
    NSInteger nextPage = [pageController currentPage];
    switch (nextPage)
    {
        case 0:
            [_webView1 setHidden:NO];
            [_webView2 setHidden:YES];
            [_webView3 setHidden:YES];
            [_webView4 setHidden:YES];
            [_webView5 setHidden:YES];
            break;
        case 1:
            [_webView1 setHidden:YES];
            [_webView2 setHidden:NO];
            [_webView3 setHidden:YES];
            [_webView4 setHidden:YES];
            [_webView5 setHidden:YES];
            break;
        case 2:
            [_webView1 setHidden:YES];
            [_webView2 setHidden:YES];
            [_webView3 setHidden:NO];
            [_webView4 setHidden:YES];
            [_webView5 setHidden:YES];
            break;
        case 3:
            [_webView1 setHidden:YES];
            [_webView2 setHidden:YES];
            [_webView3 setHidden:YES];
            [_webView4 setHidden:NO];
            [_webView5 setHidden:YES];
            break;
        case 4:
            [_webView1 setHidden:YES];
            [_webView2 setHidden:YES];
            [_webView3 setHidden:YES];
            [_webView4 setHidden:YES];
            [_webView5 setHidden:NO];
            break;
        default:
            break;
    }
    prevPage = nextPage;    
}

-(void)dealloc
{
    [pageControl release];
    [_webView1 release];
    [_webView2 release];
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
