//
//  contactModel.h
//  scoreboard database
//
//  Created by Solensky, Ryan Joseph on 12/10/13.
//  Copyright (c) 2013 Solensky, Ryan Joseph. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface contactModel : NSObject

@property (nonatomic, retain) NSString* username;
@property (nonatomic, assign) int score;
@property (nonatomic, assign) int index;

-(id)init;
-(void)dealloc;

@end
