//
//  TableViewController.m
//  PhotoHunt
//
//  Created by Marks, Jonathan A on 12/10/13.
//  Copyright (c) 2013 Marks, Jonathan A; Solensky, Ryan J. All rights reserved.
//

#import "TableViewController.h"
#import "storageClass.h"
#import "ViewController.h"

@interface TableViewController ()
{

}
@end

@implementation TableViewController

@synthesize tableView = _tableView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
-(void) tableChange;
{
    [self.tableView reloadData];
}
- (void)viewDidLoad
{
    
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
}
-(IBAction)mainScreenClicked:(id)sender
{
    ViewController* vc;
    vc = [[[ViewController alloc] initWithNibName:@"ViewController" bundle:nil] autorelease];
    [self.navigationController pushViewController:vc animated:NO];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                       reuseIdentifier:CellIdentifier] autorelease];
    }
    
    contactModel* cellValue = [[storageClass shared].list objectAtIndex:indexPath.row];
    NSString* string =[NSString stringWithFormat:@"%i --       %@", cellValue.score, cellValue.username];
    cell.textLabel.text = string;
    return cell;
}

-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[storageClass shared] .list count];
}

- (void)didReceiveMemoryWarning
{
    self.navigationController.navigationBar.hidden = YES;
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
