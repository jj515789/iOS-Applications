//
//  ContactModel.m
//  ContactList
//
//  Created by Marks, Jonathan A on 10/23/13.
//  Copyright (c) 2013 Marks, Jonathan A. All rights reserved.
//

#import "ContactModel.h"
#import "Storage.h"


@implementation ContactModel

@synthesize firstName = _firstName;
@synthesize lastName = _lastName;
@synthesize email = _email;
@synthesize phone = _phone;

-(id)init
{
    self = [super init];
    if(!self)
    {
        return nil;
    }
    
    _firstName = [[NSString alloc] init];
    _lastName = [[NSString alloc] init];
    _email = [[NSString alloc] init];
    _phone = [[NSString alloc] init];
  
    return self;
}

+(NSDictionary*) toDictionary: (ContactModel*) c
{
    NSMutableDictionary *d = [NSMutableDictionary dictionaryWithObjectsAndKeys:c.firstName, @"fn",
                                                                 c.lastName, @"ln",
                                                                 c.email, @"email",
                                                                 c.phone, @"phone", nil];
    return d;
}
+(ContactModel*) toContact: (NSMutableDictionary*) d;
{
    ContactModel* c = [[ContactModel alloc] init];
    c.firstName = [d objectForKey:@"fn"];
    c.lastName = [d objectForKey:@"ln"];
    c.email = [d objectForKey:@"email"];
    c.phone = [d objectForKey:@"phone"];
    return c;
}
-(void)dealloc
{
    [_firstName release];
    [_lastName release];
    [_email release];
    [_phone release];
    
    [super dealloc];
}
@end
