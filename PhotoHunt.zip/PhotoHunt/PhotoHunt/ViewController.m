//
//  ViewController.m
//  PhotoHunt
//
//  Created by Marks, Jonathan A on 12/4/13.
//  Copyright (c) 2013 Marks, Jonathan A; Solensky, Ryan J. All rights reserved.
//

#import "ViewController.h"
#import "Round1.h"
#import "TableViewController.h"
#import "storageClass.h"
#import "contactModel.h"

@interface ViewController ()
{
    
}

@property(nonatomic, retain)IBOutlet UIView* titleBox;
@property(nonatomic, retain)IBOutlet UIButton *start;

@end

@implementation ViewController

@synthesize titleBox = _titleBox;
@synthesize start = _start;

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft || interfaceOrientation == UIInterfaceOrientationLandscapeRight);
}
- (IBAction)startClicked:(id)sender
{
    Round1* vc;
    vc = [[[Round1 alloc] initWithNibName:@"Round1" bundle:nil] autorelease];
    [self.navigationController pushViewController:vc animated:YES];
}
-(void) showButton
{
    self.start.hidden = NO;
}
- (void)viewDidLoad
{
    [[storageClass shared] testData];
    self.navigationController.navigationBar.hidden = YES;
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}
-(void)finger
{
    UIImageView *imageView5 = [[UIImageView alloc] initWithFrame:CGRectMake(700, 500, 100, 100)];
    [imageView5 setImage:[UIImage imageNamed:@"pointing-finger-hi.png"]];
    [self.view addSubview:imageView5];
    
    [UIView animateWithDuration:0.65
                          delay:2.0
                        options:(UIViewAnimationOptionTransitionCurlUp)
                     animations:^{
                         imageView5.alpha = 0.0;
                     }
                     completion:^(BOOL completed) {}];
    
	[imageView5 release];
}

-(void) circle
{
    //Circles the item
    UIImageView *imageView6 = [[UIImageView alloc] initWithFrame:CGRectMake(665, 460, 100, 100)];
    [imageView6 setImage:[UIImage imageNamed:@"ToM_EnsoCircle.png"]];
    [self.view addSubview:imageView6];
    
    [UIImageView animateWithDuration:0 animations:^{imageView6.alpha = 0.0;}];  // fade it out right away so it doesnt show
	
	
	// fade  in  circle
	[UIView animateWithDuration:1.0
                          delay:6.0
                        options:(UIViewAnimationOptionTransitionCurlUp)
                     animations:^{
                         imageView6.alpha = 1.0;
                     }
                     completion:^(BOOL completed) {}];
	[imageView6 release];
}
-(void)viewWillAppear:(BOOL)animated
{
    //Background Image
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 513, 374)];
    [imageView setImage:[UIImage imageNamed:@"3_7802_en_i-spy-mystery_1.png"]];
    [self.view addSubview:imageView];
    [self.view sendSubviewToBack:imageView];
    imageView.alpha = .78;
    [imageView release];
    
    //Background Image
    UIImageView *imageView2 = [[UIImageView alloc] initWithFrame:CGRectMake(513, 0, 513, 374)];
    [imageView2 setImage:[UIImage imageNamed:@"i-spy-fantasy_1_big.png"]];
    [self.view addSubview:imageView2];
    [self.view sendSubviewToBack:imageView2];
    imageView2.alpha = .78;
    [imageView2 release];
    
    //Background Image
    UIImageView *imageView3 = [[UIImageView alloc] initWithFrame:CGRectMake(0, 374, 513, 374)];
    [imageView3 setImage:[UIImage imageNamed:@"x017(pp_w900_h677).png"]];
    [self.view addSubview:imageView3];
    [self.view sendSubviewToBack:imageView3];
    imageView3.alpha = .82;
    [imageView3 release];
    
    //Background Image
    UIImageView *imageView4 = [[UIImageView alloc] initWithFrame:CGRectMake(511, 374, 513, 374)];
    [imageView4 setImage:[UIImage imageNamed:@"I-SPY-Fun-House_2.png"]];
    [self.view addSubview:imageView4];
    [self.view sendSubviewToBack:imageView4];
    imageView4.alpha = .82;
    [imageView4 release];
    
    //title box
	CGRect startFrame;
	startFrame = 	CGRectMake(-250, 170, 150, 50);  // off screen left
	self.titleBox.frame = startFrame;
	
	CGRect destFrame;
	destFrame = CGRectMake(100, 170, 150, 50); // on the screen
	
	
	[UIView beginAnimations:nil context:nil];
	[UIView setAnimationDelay:1.0];
	[UIView setAnimationDuration:1.5];
	[UIView setAnimationCurve:UIViewAnimationCurveLinear];
	self.titleBox.frame = destFrame;
	[UIView commitAnimations];
    
    
	// programmaitcally add a label
	UILabel* boxTextLabel;
	boxTextLabel = [[UILabel alloc]initWithFrame:CGRectMake(52, 83, 300, 60)]; // relative to parent view
	boxTextLabel.font = [UIFont fontWithName:@"Didot-Bold" size:151.0];
    boxTextLabel.text = @"Photo Hunt";
	boxTextLabel.backgroundColor = [UIColor clearColor];
    boxTextLabel.textColor = [UIColor blackColor];
    [boxTextLabel sizeToFit];
    
	
	
	[self.titleBox addSubview:boxTextLabel];
	[UIView animateWithDuration:0 animations:^{boxTextLabel.alpha = 0.0;}];  // fade it out right away so it doesnt show
	
	
	// fade  in  label
	[UIView animateWithDuration:1.9
                          delay:2.25
                        options:(UIViewAnimationOptionTransitionCurlUp)
                     animations:^{
                         boxTextLabel.alpha = 1.0;
                     }
                     completion:^(BOOL completed) {}];
	[boxTextLabel release];
    
    UILabel* boxTextLabel2;
	boxTextLabel2 = [[UILabel alloc]initWithFrame:CGRectMake(50, 80, 300, 60)]; // relative to parent view
	boxTextLabel2.font = [UIFont fontWithName:@"Didot-Bold" size:150.0];
    boxTextLabel2.text = @"Photo Hunt";
	boxTextLabel2.backgroundColor = [UIColor clearColor];
    boxTextLabel2.textColor = [UIColor whiteColor];
    [boxTextLabel2 sizeToFit];
    
    [self.titleBox addSubview:boxTextLabel2];
	[UIView animateWithDuration:0 animations:^{boxTextLabel2.alpha = 0.0;}];  // fade it out right away so it doesnt show
	
	
	// fade  in  label
	[UIView animateWithDuration:1.9
                          delay:2.25
                        options:(UIViewAnimationOptionTransitionCurlUp)
                     animations:^{
                         boxTextLabel2.alpha = 1.0;
                     }
                     completion:^(BOOL completed) {}];
	[boxTextLabel2 release];
    
    [self performSelector:@selector(finger) withObject:self afterDelay:5.3];
    
    [self circle];
    
    [self performSelector:@selector(showButton) withObject:self afterDelay:8.0];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
