//
//  ViewController.h
//  tipcalculator
//
//  Created by Marks, Jonathan A on 9/25/13.
//  Copyright (c) 2013 Marks, Jonathan A. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

{
    IBOutlet UITextField *bill;
    IBOutlet UILabel *thelabel;
    IBOutlet UITextField *total;
}

@property(nonatomic, retain)UITextField *bill;
@property(nonatomic, retain) UILabel *thelabel;
@property(nonatomic, retain) UITextField *total;

-(IBAction)btnClicked:(id)sender;
+(BOOL) isNumeric:(NSString*) s;

@end
