//
//  ViewController.m
//  ContactList
//
//  Created by Marks, Jonathan A on 10/23/13.
//  Copyright (c) 2013 Marks, Jonathan A. All rights reserved.
//

#import "ViewController.h"
#import "ContactModel.h"
#import "Storage.h"
#import "SecondViewController.h"

@interface ViewController ()

@end

@implementation ViewController

@synthesize num = _num;
@synthesize tableView = _tableView;

-(void)addButtonClick
{
    _num = -1;
    SecondViewController* vc;
    vc = [[[SecondViewController alloc] initWithNibName:@"SecondViewController" bundle:nil]autorelease];
    [vc setIndex: _num];
    vc.reloadDelegate = self;
    [self.navigationController pushViewController:vc animated:YES];
}
-(void) tableChange;
{
    [self.tableView reloadData];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    
   UIBarButtonItem *addButton = [[UIBarButtonItem alloc]
                                  initWithTitle:@"Add" style:UIBarButtonItemStylePlain target:self
                                 action:@selector(addButtonClick)];
    self.navigationItem.rightBarButtonItem = addButton;
    [addButton release];
    
    [[Storage shared]  updateContactList];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[[Storage shared] getAllContacts] count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";

    UITableViewCell *cell =
    [tableView dequeueReusableCellWithIdentifier:CellIdentifier];

    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
                                       reuseIdentifier:CellIdentifier]
                autorelease];
    }
    ContactModel* c = [[Storage shared] getContact: indexPath.row];
    NSString* str = [NSString stringWithFormat:@"%@, %@", c.lastName, c.firstName];
    cell.textLabel.text = str;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    SecondViewController *vc;
    vc = [[SecondViewController alloc] initWithNibName:@"SecondViewController" bundle:nil];
    
    NSMutableDictionary *d = [ContactModel toDictionary:[[Storage shared] getContact: indexPath.row]];
    [vc setDict: d];
    [vc setIndex: indexPath.row];
    vc.reloadDelegate = self;
    [self.navigationController pushViewController:vc animated:YES];
    [vc release];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

